create function polygon(circle) returns polygon
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function polygon(path) is 'convert circle to 12-vertex polygon';

alter function polygon(path) owner to postgres;

