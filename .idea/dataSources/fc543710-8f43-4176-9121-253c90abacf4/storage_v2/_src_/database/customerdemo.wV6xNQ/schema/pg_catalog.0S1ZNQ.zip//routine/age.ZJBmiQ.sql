create function age(timestamp without time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function age(timestamp) owner to postgres;

