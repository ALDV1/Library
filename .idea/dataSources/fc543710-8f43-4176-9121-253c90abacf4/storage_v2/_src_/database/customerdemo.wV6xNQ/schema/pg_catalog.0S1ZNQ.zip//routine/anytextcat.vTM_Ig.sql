create function anytextcat(anynonarray, text) returns text
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$select $1::pg_catalog.text operator(pg_catalog.||) $2$$;

alter function anytextcat(anynonarray, text) owner to postgres;

