create function shobj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function shobj_description(oid, name) owner to postgres;

